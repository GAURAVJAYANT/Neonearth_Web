// @ts-check
const { defineConfig, devices } = require('@playwright/test');
require('dotenv').config();

module.exports = defineConfig({
  testDir: './tests',
  fullyParallel: true,
  workers: 20,
  retries: 2,
  timeout: 60 * 5000, // ✅ Changed from 30 to 60
  expect: {
    timeout: 40 * 1000,
  },
  globalTeardown: require.resolve('./global-teardown.js'),
  reporter: [
    ['list'],
    ['monocart-reporter', {
      name: "Test Automation Dashboard",
      outputFile: './test-results/report.html',
    }],
    ['json', { outputFile: 'test-results/report.json' }],
    ['./open-report-reporter.js']
  ],
  use: {
    baseURL: 'https://test.neonearth.com',
    trace: 'on-first-retry',
    video: {
      mode: 'retain-on-failure',
      size: { width: 1920, height: 1080 }
    },
    screenshot: 'only-on-failure',
    headless: false,
    viewport: null,
    launchOptions: {
      args: ["--start-maximized"],
    },
    permissions: ['geolocation'],
    geolocation: { latitude: 40.7128, longitude: -74.0060 }, // New York, NY
  },
});